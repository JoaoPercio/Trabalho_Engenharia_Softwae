export const HOME_URL = Object.freeze({
  path: '/',
  name: 'home',
  components: {
    path: '/components',
    name: 'home.components',
  },
});
