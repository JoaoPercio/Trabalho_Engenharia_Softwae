<template>
  <div>
    <slot />
  </div>
</template>
<style lang="scss" scoped>
div {
  display: contents;
}
</style>
