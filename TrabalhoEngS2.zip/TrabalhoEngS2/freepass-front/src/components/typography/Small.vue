<template>
  <div class="biblioteca-small">
    <slot />
  </div>
</template>

<script>
export default {
  name: 'BibliotecaSmall',
};
</script>
